#pragma once
#ifndef GAME_H
#define GAME_H

void reset();
void callback(const int key);
void run();
void exit();
void start();

#endif