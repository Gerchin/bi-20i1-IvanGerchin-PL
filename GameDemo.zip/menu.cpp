#pragma once
#include "main.h"

void showMenu() {
	cout << "Game demo." << endl;
	cout << "1. Start" << endl;
	cout << "2. Show settings" << endl;
	cout << "3. Exit" << endl;
}

int selectItemMenu() {
	int itemMenu = 0;
	cin >> itemMenu;

	return itemMenu;
}