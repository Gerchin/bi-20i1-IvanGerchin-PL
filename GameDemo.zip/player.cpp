#pragma once
#include "main.h"

void movePlayer(const int key) {
	int dx = 0;
	int dy = 0;
	bool isRender = true;

	switch (key)
	{
	case 72:
		dy = -1;
		break;
	case 80:
		dy = 1;
		break;
	case 75:
		dx = -1;
		break;
	case 77:
		dx = 1;
		break;
	default:
		isRender = false;
		break;
	}

	if ((coordPlayerY + dy) < (heigth - 1) &&
		(coordPlayerY + dy) > 0 &&
		(coordPlayerX + dx) < (width - 1) &&
		(coordPlayerX + dx) > 0 &&
		!map[coordPlayerY + dy][coordPlayerX + dx] &&
		isRender)
	{
		coordPlayerY += dy;
		coordPlayerX += dx;
	}

}

bool isFinish() {
	if (coordPlayerX == coordFinishX &&
		coordPlayerY == coordFinishY)
		return true;
	return false;
}
