#pragma once
#include "main.h"

void generatePositionFinish() {
	do {
		coordFinishX = rand() % (width - 2) + 1;
		coordFinishY = rand() % (heigth - 2) + 1;
	} while (map[coordFinishY][coordFinishX] ||
			 (coordFinishX == coordPlayerX &&
			 coordFinishY == coordPlayerY)
			);
}

void generateStartPositionPlayer() {
	do {
		coordPlayerX = rand() % (width - 2) + 1;
		coordPlayerY = rand() % (heigth - 2) + 1;
	} while (map[coordPlayerY][coordPlayerX]);
}


/*void startTrack() {
	int track[heigth][width] = {};
}*/

bool isCanBlock(int x, int y) {
	bool leftField = map[x - 1][y];
	bool topField = map[x][y - 1];
	bool bottomField = map[x][y + 1];
	bool rightField = map[x + 1][y];
	int countEmpty = 0;

	if (leftField == false) {
		countEmpty++;
	}
	
	if (topField == false) {
		countEmpty++;
	}
	
	if (bottomField == false) {
		countEmpty++;
	}
	
	if (rightField == false) {
		countEmpty++;
	}

	if (countEmpty > 2)
		return true;
	return false;
}

void clearMap() {
	for (int i = 0; i < heigth; i++)
	{
		for (int j = 0; j < width; j++)
		{
			map[i][j] = false;
		}
	}
}
void generateMap() {
	srand(time(NULL));
	int counter = 0;
	clearMap();

	do{
		int y = rand() % (width - 2) + 1;
		int x = rand() % (heigth - 2) + 1;
		
		if (isCanBlock(x, y)) {
			map[x][y] = true;
			counter++;
		}

	} while (counter < countBlock);
}

void renderMap() {
	system("cls");

	for (int i = 0; i < heigth; i++)
	{
		if (i == 0 || i == heigth - 1)
		{
			for (int j = 0; j < width; j++)
			{
				cout << "#";
			}

			cout << endl;
		}
		else
		{
			for (int j = 0; j < width; j++)
			{
				if (i == coordPlayerY && j == coordPlayerX)
					cout << "X";
				else if (i == coordFinishY && j == coordFinishX)
					cout << "$";
				else if (j == 0 || j == width - 1)
					cout << "|";
				else if (map[i][j])
					cout << "#";
				else
					cout << " ";
			}

			cout << endl;
		}
	}
}