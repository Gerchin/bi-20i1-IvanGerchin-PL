#pragma once
#ifndef MENU_H
#define MENU_H

void showMenu();
int selectItemMenu();

#endif