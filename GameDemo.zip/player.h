#pragma once
#ifndef PLAYER_H
#define PLAYER_H

void movePlayer(const int key);
bool isFinish();

#endif