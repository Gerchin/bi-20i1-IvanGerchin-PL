#pragma once
#ifndef MAP_H
#define MAP_H

void generatePositionFinish();
void generateStartPositionPlayer();
bool isCanBlock(int x, int y);
void clearMap();
void generateMap();

void renderMap();

#endif