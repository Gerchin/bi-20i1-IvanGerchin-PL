#include "main.h"
const int heigth = 10;
const int width = 20;

bool map[heigth][width];

const int countBlock = 20;

int coordFinishX;
int coordFinishY;

int coordPlayerX;
int coordPlayerY;

void showSettings() {
	system("cls");
	cout << "Information of settings." << endl;
	cout << "coutBlock: " << countBlock << endl;
	cout << "sizeMap: [" << width << ", " << heigth << "]" << endl;
	system("pause");
}
