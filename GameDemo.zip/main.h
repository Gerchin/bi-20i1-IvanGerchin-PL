#pragma once
#ifndef MAIN_H
#define MAIN_H

#include <conio.h>
#include <iostream>
#include <ctime>

using namespace std;

#include "settings.h"
#include "menu.h"
#include "player.h"
#include "map.h"
#include "game.h"

#endif MAIN_H
